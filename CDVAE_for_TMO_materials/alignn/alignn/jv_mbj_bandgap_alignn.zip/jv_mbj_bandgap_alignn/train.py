from alignn.train_props import train_prop_model 
train_prop_model(batch_size=64,learning_rate=0.001,prop="mbj_bandgap")
